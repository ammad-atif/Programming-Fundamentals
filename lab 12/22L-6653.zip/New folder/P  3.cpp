//#include<iostream>
//using namespace std;
//void av(int a[][4], int sr, float b[])
//{
//	float sum;
//	for (int i = 0; i < sr; i++)
//	{
//		sum = 0;
//		for (int j = 0; j < 4; j++)
//		{
//			sum = sum + a[i][j];
//		}
//		b[i] = sum;
//	}
//}
//int main()
//{
//	int a_2D[3][4] = { {7,0,-9,9},{0,5,0,3},{4,0,6,1} };
//	//size of 1_D array depends on the number of rows of 2_D array
//	float a_1D[3];
//	//the function will require a 2_D and 1_D array and size of rows of 2_D array
//	av(a_2D, 3, a_1D);
//	for (int i = 0; i < 3; i++)
//	{
//		cout << a_1D[i] << endl;
//	}
//}