//#include<iostream>
//#include<fstream>
//using namespace std;
//void f(char a[],char b[], char c[])
//{
//	ofstream z(a);
//	z << c;
//	z.close();
//	char d[100];
//	ifstream w(a);
//	w.getline(d, 100);
//	w.close();
//	cout << d;
//	ofstream y(b);
//	y << d;
//	y.close();
//}
//int main()
//{
//	char c[100] = "Hello welcome to the file!";
//	char a[100] = "hello.txt";
//	char b[100] = "hell.txt";
//	f(a, b,c);
//}