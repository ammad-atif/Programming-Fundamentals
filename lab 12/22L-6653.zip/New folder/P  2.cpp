//#include<iostream>
//using namespace std;
//void av(int a[][4], int sr, float b[])
//{
//	float sum;
//	for (int i = 0; i < 4; i++)
//	{
//		sum = 0;
//		for (int j = 0; j < sr; j++)
//		{
//			sum = sum + a[j][i];
//		}
//		sum = sum / 3;
//		b[i] = sum;
//	}
//}
//int main()
//{
//	int a_2D[3][4] = { {7,0,-9,9},{0,5,0,3},{4,0,6,1} };
//	//size of 1_D array depends on the number of columns of 2_D array
//	float a_1D[4];
//	//the function will require a 2_D and 1_D array and size of rows of 2_D array
//	av(a_2D, 3, a_1D);
//	for (int i = 0; i < 4; i++)
//	{
//		cout << a_1D[i] << endl;
//	}
//}