//#include<iostream>
//#include<fstream>
//using namespace std;
//void f(char a[], int x, int y)
//{
//	ofstream z(a);
//	z << x;
//	z << y;
//	z.close();
//	int c;
//	ifstream w(a);
//	while (w.eof() == 0)
//	{
//		w >> c;
//	}
//	cout<< c;
//	w.close();
//}
//int main()
//{
//	char a[100] = "numbers.txt";
//	f(a, 1, 2);
//}