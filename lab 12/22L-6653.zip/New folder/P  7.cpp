//#include<iostream>
//#include<fstream>
//using namespace std;
//void f(char a[], char b[])
//{
//	int maxsize=0;
//	for (int i = 0; b[i]!='\0'; i++)
//	{
//		maxsize++;
//	}
//	ofstream z(a);
//	z << b;
//	z.close();
//	char c[100]="0";
//	int currentsize, x=0;
//	ifstream w(a);
//	while (w.eof()==0)
//	{
//		x = 0;
//		w >> c;
//		cout << c<<" ";
//		for (int i = 0; c[i]!='\0'; i++)
//		{
//			x++;
//		}
//		currentsize = maxsize - x;
//	}
//	w.close();
//}
//int main()
//{
//	char b[100] = "Hello welcome to the file!";
//	char a[100] = "h.txt";
//	f(a, b);
//}