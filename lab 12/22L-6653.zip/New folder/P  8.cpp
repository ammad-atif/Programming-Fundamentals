//#include<iostream>
//#include<fstream>
//using namespace std;
//void f(char a[], char b[])
//{
//	ofstream z(a);
//	z << b;
//	z.close();
//	char c[100];
//	ifstream w(a);
//	w.getline(c, 100);
//	w.close();
//	cout << c;
//}
//int main()
//{
//	char b[100] = "Hello welcome to the file!";
//	char a[100] = "hello.txt";
//	f(a, b);
//}