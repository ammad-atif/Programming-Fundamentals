//#include<iostream>
//#include<fstream>
//using namespace std;
//void f(char a[], char b[])
//{
//	ofstream z(a);
//	z << b;
//	z.close();
//}
//int main()
//{
//	char a[100] = "file.txt";
//	char b[100] = "Hello waelcome to file!";
//	f(a, b);
//}