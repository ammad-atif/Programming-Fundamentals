//#include<iostream>
//using namespace std;
//void print_arr(int a[][4],int s)
//{
//	for (int i = 0; i < s; i++)
//	{
//		for (int j = 0; j < 4; j++)
//		{
//			cout << a[i][j] << endl;
//		}
//	}
//}
//int main()
//{
//	int a[3][4] = { {1,2},{5,9,1} };
//	print_arr(a, 3);
//	/*printing zero instead of those which are not initializewd*/
//}