//#include <iostream>
//#include <stdlib.h>;
//#include<string>;
//using namespace std;
//int main()
//{
//	int num1 = 0, num2 = 0, sel = 0, i = 1, fsum = 1,func=0,rem=0;
//	string x = "0";
//	cout << "Enter 1 for addition\n" << "Enter 2 for division\n" << "Enter 3 for magnitude\n" << "Enter 4 for factorial\n";
//	cin >> sel;
//	while (sel != 5)
//	{
//		if (sel == 1)
//		{
//			cout << "Enter first number\n";
//			cin >> num1;
//			cout << "Enter second number\n";
//			cin >> num2;
//			func = num1 + num2;
//			cout << "Answer is\n " << func<<endl;
//
//		}
//		else if (sel == 2)
//		{
//			cout << "Enter dividend\n";
//			cin >> num1;
//			cout << "Enter divisor\n";
//			cin >> num2;
//			func = num1 / num2;
//            rem=num1%num2;
//			cout << "Quotient is\n" << func << endl<<"Remainder is "<<endl<<rem<<endl;
//		}
//		else if (sel == 3)
//		{
//			cout << "Enter number\n";
//			cin >> num1;
//			if (num1 >= 0)
//			{
//				cout << "Magnitude is\n" << num1<<endl;
//			}
//			else
//			{
//				cout << "Magnitude is\n" << -num1<<endl;
//
//			}
//		}
//		else if (sel == 4)
//		{
//			cout << "Enter number for factorial\n";
//			cin >> num1;
//			while (i < num1 + 1)
//			{
//				fsum = i * fsum;
//				i = i + 1;
//			}
//			cout << "Factorial is\n" << fsum<<endl;
//		}
//		else 
//		{	
//			cout << "You have entered wrong option\n";
//		}
//		cout << "Press and enter any key to return to menu\n";
//		cin >> x;
//		system("CLS");
//		cout << "Enter 1 for addition\n" << "Enter 2 for division\n" << "Enter 3 for magnitude\n" << "Enter 4 for factorial\n";
//		cin >> sel;
//	}
//}