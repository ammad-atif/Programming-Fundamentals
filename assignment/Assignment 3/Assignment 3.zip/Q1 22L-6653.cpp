//#include <iostream>
//using namespace std;
//int main()
//{
//	int num = 0, sum = 0, rem = 0;
//	cout << "Enter the integer\n";
//	cin >> num;
//	while (num > 0)
//	{
//		rem = num % 10;
//		sum = sum + rem;
//		num = num / 10;
//	}
//	cout << sum;
//}